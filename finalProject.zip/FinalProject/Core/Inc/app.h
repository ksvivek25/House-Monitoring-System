/*
 * app_Lab2_2.h
 *
 *  Created on: Sep 10, 2024
 *      Author: Julian
 */

#ifndef INC_APP_LAB2_2_H_
#define INC_APP_LAB2_2_H_

#include "stm32l4xx_hal.h"


void App_Init(void);
void App_MainLoop(void);

#endif /* INC_APP_LAB2_2_H_ */
